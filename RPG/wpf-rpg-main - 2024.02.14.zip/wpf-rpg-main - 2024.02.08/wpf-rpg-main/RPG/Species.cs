﻿namespace RPG
{
    public enum Species
    {
        Human,
        Stonekin,
        Swiftlings,
        Vitaleons,
        Shadowsneak,
        Maguskin,
        Bruteforce,
        Quicksylph,
        Mysticore,
        Ironheart,
        Fleetspell,
        Enemy
    }
    public static class SpeciesHelper
    {

    }
}
